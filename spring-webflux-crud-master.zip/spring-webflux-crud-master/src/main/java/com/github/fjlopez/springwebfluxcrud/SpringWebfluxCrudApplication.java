package com.github.fjlopez.springwebfluxcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebfluxCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebfluxCrudApplication.class, args);
	}
}
